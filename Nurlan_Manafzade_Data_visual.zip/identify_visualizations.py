import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import os
from matplotlib import font_manager
import matplotlib as mpl

# Set up the output directory for visualizations
output_dir = '/home/ubuntu/visualizations'
os.makedirs(output_dir, exist_ok=True)

# Load the data
file_path = '/home/ubuntu/upload/Data_visual.xlsx'
df = pd.read_excel(file_path, sheet_name='Əsas data')

# Convert date columns to datetime
df['Order Date'] = pd.to_datetime(df['Order Date'])
df['Ship Date'] = pd.to_datetime(df['Ship Date'])

# Extract year and month for time-based analysis
df['Year'] = df['Order Date'].dt.year
df['Month'] = df['Order Date'].dt.month
df['Quarter'] = df['Order Date'].dt.quarter

# Based on the data analysis, here are potential visualizations:

print("Identifying potential visualizations based on data analysis...")

# List of potential visualizations
visualizations = [
    "1. Sales by Region - Bar Chart",
    "2. Profit by Category - Bar Chart",
    "3. Sales Trend Over Time - Line Chart",
    "4. Sales vs. Profit by Category - Scatter Plot",
    "5. Discount vs. Profit - Scatter Plot",
    "6. Sales Distribution by Segment - Pie Chart",
    "7. Top 10 Countries by Sales - Horizontal Bar Chart",
    "8. Correlation Heatmap of Numerical Variables",
    "9. Sales by Ship Mode - Bar Chart",
    "10. Profit Margin by Category - Bar Chart",
    "11. Quantity Distribution - Histogram",
    "12. Sales by Market - Bar Chart",
    "13. Monthly Sales Trend - Line Chart",
    "14. Quarterly Profit Trend - Line Chart",
    "15. Sub-Category Performance - Horizontal Bar Chart"
]

# Print the list of potential visualizations
print("\nPotential Visualizations:")
for viz in visualizations:
    print(viz)

# Save the list of potential visualizations
with open(f"{output_dir}/potential_visualizations.txt", 'w') as f:
    f.write("Potential Visualizations Based on Data Analysis:\n\n")
    for viz in visualizations:
        f.write(f"{viz}\n")
    
    # Add rationale for each visualization
    f.write("\n\nRationale for Selected Visualizations:\n\n")
    
    f.write("1. Sales by Region - Bar Chart:\n")
    f.write("   - Shows total sales across different regions\n")
    f.write("   - Helps identify top-performing regions\n")
    f.write("   - Suitable for the 13 unique regions in the dataset\n\n")
    
    f.write("2. Profit by Category - Bar Chart:\n")
    f.write("   - Displays profitability across the 3 product categories\n")
    f.write("   - Simple and effective for comparing a small number of categories\n\n")
    
    f.write("3. Sales Trend Over Time - Line Chart:\n")
    f.write("   - Visualizes sales patterns over time\n")
    f.write("   - Helps identify seasonality and growth trends\n")
    f.write("   - Uses the datetime-converted 'Order Date' column\n\n")
    
    f.write("4. Sales vs. Profit by Category - Scatter Plot:\n")
    f.write("   - Shows relationship between sales and profit\n")
    f.write("   - Color-coded by category to identify category-specific patterns\n")
    f.write("   - Helps identify high-sales but low-profit categories\n\n")
    
    f.write("5. Discount vs. Profit - Scatter Plot:\n")
    f.write("   - Examines the impact of discounts on profitability\n")
    f.write("   - The correlation analysis showed a negative correlation (-0.32) between discount and profit\n\n")
    
    f.write("6. Sales Distribution by Segment - Pie Chart:\n")
    f.write("   - Shows the proportion of sales across the 3 segments\n")
    f.write("   - Suitable for the low cardinality of the Segment column\n\n")
    
    f.write("7. Top 10 Countries by Sales - Horizontal Bar Chart:\n")
    f.write("   - Focuses on the highest-performing countries\n")
    f.write("   - Horizontal orientation works well for country names\n")
    f.write("   - Reduces the high cardinality (147 countries) to a manageable visualization\n\n")
    
    f.write("8. Correlation Heatmap of Numerical Variables:\n")
    f.write("   - Visualizes the correlation matrix of all numerical variables\n")
    f.write("   - Helps identify relationships between Sales, Shipping Cost, Profit, Quantity, and Discount\n\n")
    
    f.write("9. Sales by Ship Mode - Bar Chart:\n")
    f.write("   - Compares sales across the 4 shipping methods\n")
    f.write("   - May reveal preferences or patterns in shipping choices\n\n")
    
    f.write("10. Profit Margin by Category - Bar Chart:\n")
    f.write("    - Shows profit as a percentage of sales for each category\n")
    f.write("    - Provides insight into relative profitability beyond absolute numbers\n\n")
    
    f.write("11. Quantity Distribution - Histogram:\n")
    f.write("    - Shows the distribution of order quantities\n")
    f.write("    - Helps understand typical order sizes\n\n")
    
    f.write("12. Sales by Market - Bar Chart:\n")
    f.write("    - Compares sales across the 4 markets\n")
    f.write("    - Simple visualization for a low-cardinality categorical variable\n\n")
    
    f.write("13. Monthly Sales Trend - Line Chart:\n")
    f.write("    - Shows monthly sales patterns\n")
    f.write("    - Helps identify seasonal trends within years\n\n")
    
    f.write("14. Quarterly Profit Trend - Line Chart:\n")
    f.write("    - Visualizes quarterly profit patterns\n")
    f.write("    - Provides a less granular view than monthly for clearer trend identification\n\n")
    
    f.write("15. Sub-Category Performance - Horizontal Bar Chart:\n")
    f.write("    - Compares performance across the 17 sub-categories\n")
    f.write("    - Horizontal orientation works well for sub-category names\n")

print(f"\nPotential visualizations list saved to {output_dir}/potential_visualizations.txt")
