import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import os
from matplotlib import font_manager, rcParams
import matplotlib as mpl
from datetime import datetime

# Set up the output directory for visualizations
output_dir = '/home/ubuntu/visualizations'
os.makedirs(output_dir, exist_ok=True)

# Configure matplotlib for better handling of multilingual text
plt.rcParams['font.family'] = ['DejaVu Sans', 'Arial', 'sans-serif']

# Load the data
file_path = '/home/ubuntu/upload/Data_visual.xlsx'
df = pd.read_excel(file_path, sheet_name='Əsas data')

# Convert date columns to datetime
df['Order Date'] = pd.to_datetime(df['Order Date'])
df['Ship Date'] = pd.to_datetime(df['Ship Date'])

# Extract year and month for time-based analysis
df['Year'] = df['Order Date'].dt.year
df['Month'] = df['Order Date'].dt.month
df['Quarter'] = df['Order Date'].dt.quarter
df['YearMonth'] = df['Order Date'].dt.strftime('%Y-%m')

# Calculate profit margin
df['Profit Margin'] = df['Profit'] / df['Sales']

print("Creating data visualizations...")

# 1. Sales by Region - Bar Chart
plt.figure(figsize=(12, 6))
region_sales = df.groupby('Region')['Sales'].sum().sort_values(ascending=False)
sns.barplot(x=region_sales.index, y=region_sales.values)
plt.title('Total Sales by Region', fontsize=16)
plt.xlabel('Region', fontsize=12)
plt.ylabel('Total Sales', fontsize=12)
plt.xticks(rotation=45, ha='right')
plt.tight_layout()
plt.savefig(f"{output_dir}/1_sales_by_region.png", dpi=300)
plt.close()

# 2. Profit by Category - Bar Chart
plt.figure(figsize=(10, 6))
category_profit = df.groupby('Category')['Profit'].sum().sort_values(ascending=False)
sns.barplot(x=category_profit.index, y=category_profit.values)
plt.title('Total Profit by Category', fontsize=16)
plt.xlabel('Category', fontsize=12)
plt.ylabel('Total Profit', fontsize=12)
plt.tight_layout()
plt.savefig(f"{output_dir}/2_profit_by_category.png", dpi=300)
plt.close()

# 3. Sales Trend Over Time - Line Chart
plt.figure(figsize=(14, 6))
time_sales = df.groupby('YearMonth')['Sales'].sum().reset_index()
time_sales['YearMonth'] = pd.to_datetime(time_sales['YearMonth'])
plt.plot(time_sales['YearMonth'], time_sales['Sales'], marker='o', linestyle='-')
plt.title('Sales Trend Over Time', fontsize=16)
plt.xlabel('Date', fontsize=12)
plt.ylabel('Total Sales', fontsize=12)
plt.grid(True, alpha=0.3)
plt.tight_layout()
plt.savefig(f"{output_dir}/3_sales_trend_over_time.png", dpi=300)
plt.close()

# 4. Sales vs. Profit by Category - Scatter Plot
plt.figure(figsize=(10, 8))
category_data = df.groupby(['Category', 'Sub-Category'])[['Sales', 'Profit']].sum().reset_index()
colors = {'Furniture': 'blue', 'Office Supplies': 'green', 'Technology': 'red'}
for category in category_data['Category'].unique():
    subset = category_data[category_data['Category'] == category]
    plt.scatter(subset['Sales'], subset['Profit'], label=category, 
                color=colors[category], alpha=0.7, s=100)
plt.title('Sales vs. Profit by Category and Sub-Category', fontsize=16)
plt.xlabel('Total Sales', fontsize=12)
plt.ylabel('Total Profit', fontsize=12)
plt.grid(True, alpha=0.3)
plt.legend()
plt.tight_layout()
plt.savefig(f"{output_dir}/4_sales_vs_profit_by_category.png", dpi=300)
plt.close()

# 5. Discount vs. Profit - Scatter Plot
plt.figure(figsize=(10, 8))
plt.scatter(df['Discount'], df['Profit'], alpha=0.5)
plt.title('Discount vs. Profit Relationship', fontsize=16)
plt.xlabel('Discount', fontsize=12)
plt.ylabel('Profit', fontsize=12)
plt.grid(True, alpha=0.3)
# Add trend line
z = np.polyfit(df['Discount'], df['Profit'], 1)
p = np.poly1d(z)
plt.plot(np.unique(df['Discount']), p(np.unique(df['Discount'])), "r--", alpha=0.8)
plt.tight_layout()
plt.savefig(f"{output_dir}/5_discount_vs_profit.png", dpi=300)
plt.close()

# 6. Sales Distribution by Segment - Pie Chart
plt.figure(figsize=(10, 8))
segment_sales = df.groupby('Segment')['Sales'].sum()
plt.pie(segment_sales, labels=segment_sales.index, autopct='%1.1f%%', 
        startangle=90, shadow=True, explode=[0.05, 0.05, 0.05])
plt.title('Sales Distribution by Segment', fontsize=16)
plt.axis('equal')
plt.tight_layout()
plt.savefig(f"{output_dir}/6_sales_by_segment_pie.png", dpi=300)
plt.close()

# 7. Top 10 Countries by Sales - Horizontal Bar Chart
plt.figure(figsize=(12, 8))
top10_countries = df.groupby('Country')['Sales'].sum().nlargest(10).sort_values(ascending=True)
sns.barplot(x=top10_countries.values, y=top10_countries.index)
plt.title('Top 10 Countries by Sales', fontsize=16)
plt.xlabel('Total Sales', fontsize=12)
plt.ylabel('Country', fontsize=12)
plt.tight_layout()
plt.savefig(f"{output_dir}/7_top10_countries_by_sales.png", dpi=300)
plt.close()

# 8. Correlation Heatmap of Numerical Variables
plt.figure(figsize=(10, 8))
numerical_cols = ['Sales', 'Shipping Cost', 'Profit', 'Quantity', 'Discount']
correlation = df[numerical_cols].corr()
sns.heatmap(correlation, annot=True, cmap='coolwarm', vmin=-1, vmax=1, linewidths=0.5)
plt.title('Correlation Heatmap of Numerical Variables', fontsize=16)
plt.tight_layout()
plt.savefig(f"{output_dir}/8_correlation_heatmap.png", dpi=300)
plt.close()

# 9. Sales by Ship Mode - Bar Chart
plt.figure(figsize=(10, 6))
shipmode_sales = df.groupby('Ship Mode')['Sales'].sum().sort_values(ascending=False)
sns.barplot(x=shipmode_sales.index, y=shipmode_sales.values)
plt.title('Total Sales by Ship Mode', fontsize=16)
plt.xlabel('Ship Mode', fontsize=12)
plt.ylabel('Total Sales', fontsize=12)
plt.tight_layout()
plt.savefig(f"{output_dir}/9_sales_by_ship_mode.png", dpi=300)
plt.close()

# 10. Profit Margin by Category - Bar Chart
plt.figure(figsize=(10, 6))
# Calculate average profit margin by category
profit_margin = df.groupby('Category')[['Sales', 'Profit']].sum()
profit_margin['Profit Margin'] = profit_margin['Profit'] / profit_margin['Sales'] * 100
profit_margin = profit_margin.sort_values('Profit Margin', ascending=False)
sns.barplot(x=profit_margin.index, y=profit_margin['Profit Margin'])
plt.title('Profit Margin by Category (%)', fontsize=16)
plt.xlabel('Category', fontsize=12)
plt.ylabel('Profit Margin (%)', fontsize=12)
plt.tight_layout()
plt.savefig(f"{output_dir}/10_profit_margin_by_category.png", dpi=300)
plt.close()

# 11. Quantity Distribution - Histogram
plt.figure(figsize=(10, 6))
sns.histplot(df['Quantity'], kde=True, bins=range(1, 16))
plt.title('Distribution of Order Quantities', fontsize=16)
plt.xlabel('Quantity', fontsize=12)
plt.ylabel('Frequency', fontsize=12)
plt.tight_layout()
plt.savefig(f"{output_dir}/11_quantity_distribution.png", dpi=300)
plt.close()

# 12. Sales by Market - Bar Chart
plt.figure(figsize=(10, 6))
market_sales = df.groupby('Market')['Sales'].sum().sort_values(ascending=False)
sns.barplot(x=market_sales.index, y=market_sales.values)
plt.title('Total Sales by Market', fontsize=16)
plt.xlabel('Market', fontsize=12)
plt.ylabel('Total Sales', fontsize=12)
plt.tight_layout()
plt.savefig(f"{output_dir}/12_sales_by_market.png", dpi=300)
plt.close()

# 13. Monthly Sales Trend - Line Chart
plt.figure(figsize=(14, 6))
# Group by year and month
monthly_sales = df.groupby(['Year', 'Month'])['Sales'].sum().reset_index()
# Create a datetime column for proper plotting
monthly_sales['Date'] = monthly_sales.apply(lambda x: datetime(int(x['Year']), int(x['Month']), 1), axis=1)
monthly_sales = monthly_sales.sort_values('Date')
plt.plot(monthly_sales['Date'], monthly_sales['Sales'], marker='o', linestyle='-')
plt.title('Monthly Sales Trend', fontsize=16)
plt.xlabel('Date', fontsize=12)
plt.ylabel('Total Sales', fontsize=12)
plt.grid(True, alpha=0.3)
plt.tight_layout()
plt.savefig(f"{output_dir}/13_monthly_sales_trend.png", dpi=300)
plt.close()

# 14. Quarterly Profit Trend - Line Chart
plt.figure(figsize=(14, 6))
# Group by year and quarter
quarterly_profit = df.groupby(['Year', 'Quarter'])['Profit'].sum().reset_index()
# Create a label for year-quarter
quarterly_profit['YearQuarter'] = quarterly_profit['Year'].astype(str) + '-Q' + quarterly_profit['Quarter'].astype(str)
quarterly_profit = quarterly_profit.sort_values(['Year', 'Quarter'])
plt.plot(range(len(quarterly_profit)), quarterly_profit['Profit'], marker='o', linestyle='-')
plt.xticks(range(len(quarterly_profit)), quarterly_profit['YearQuarter'], rotation=45)
plt.title('Quarterly Profit Trend', fontsize=16)
plt.xlabel('Year-Quarter', fontsize=12)
plt.ylabel('Total Profit', fontsize=12)
plt.grid(True, alpha=0.3)
plt.tight_layout()
plt.savefig(f"{output_dir}/14_quarterly_profit_trend.png", dpi=300)
plt.close()

# 15. Sub-Category Performance - Horizontal Bar Chart
plt.figure(figsize=(12, 10))
subcategory_profit = df.groupby('Sub-Category')['Profit'].sum().sort_values(ascending=True)
sns.barplot(x=subcategory_profit.values, y=subcategory_profit.index)
plt.title('Profit by Sub-Category', fontsize=16)
plt.xlabel('Total Profit', fontsize=12)
plt.ylabel('Sub-Category', fontsize=12)
plt.tight_layout()
plt.savefig(f"{output_dir}/15_subcategory_performance.png", dpi=300)
plt.close()

print(f"All visualizations created and saved to {output_dir}/")
