import pandas as pd
import os

file_path = '/home/ubuntu/upload/Data_visual.xlsx'
print(f'Excel file exists: {os.path.exists(file_path)}')

if os.path.exists(file_path):
    # Get sheet names
    excel_file = pd.ExcelFile(file_path)
    sheet_names = excel_file.sheet_names
    print(f'Excel sheets: {sheet_names}')
    
    # Preview each sheet
    for sheet in sheet_names:
        print(f"\n--- Preview of sheet '{sheet}' ---")
        df = pd.read_excel(file_path, sheet_name=sheet)
        print(f"Shape: {df.shape} (rows, columns)")
        print(f"Columns: {df.columns.tolist()}")
        print("\nFirst 5 rows:")
        print(df.head())
        print("\nData types:")
        print(df.dtypes)
