import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from datetime import datetime
import os

# Set up the output directory for visualizations
output_dir = '/home/ubuntu/visualizations'
os.makedirs(output_dir, exist_ok=True)

# Load the data
file_path = '/home/ubuntu/upload/Data_visual.xlsx'
df = pd.read_excel(file_path, sheet_name='Əsas data')

# Data structure analysis
print("Data Structure Analysis:")
print(f"Total rows: {df.shape[0]}")
print(f"Total columns: {df.shape[1]}")

# Check for missing values
missing_values = df.isnull().sum()
print("\nMissing Values:")
print(missing_values[missing_values > 0])

# Convert date columns to datetime
try:
    df['Order Date'] = pd.to_datetime(df['Order Date'])
    df['Ship Date'] = pd.to_datetime(df['Ship Date'])
    print("\nDate columns converted to datetime format")
except Exception as e:
    print(f"\nError converting date columns: {e}")

# Analyze numerical columns
numerical_cols = df.select_dtypes(include=['float64', 'int64']).columns.tolist()
print(f"\nNumerical columns: {numerical_cols}")
print("\nNumerical Data Summary:")
print(df[numerical_cols].describe())

# Analyze categorical columns
categorical_cols = df.select_dtypes(include=['object']).columns.tolist()
print(f"\nCategorical columns: {categorical_cols}")

# Count unique values in each categorical column
print("\nUnique values in categorical columns:")
for col in categorical_cols:
    unique_count = df[col].nunique()
    print(f"{col}: {unique_count} unique values")

# Check for correlations between numerical variables
print("\nCorrelation between numerical variables:")
correlation = df[numerical_cols].corr()
print(correlation)

# Save the analysis results
with open(f"{output_dir}/data_analysis.txt", 'w') as f:
    f.write("Data Structure Analysis:\n")
    f.write(f"Total rows: {df.shape[0]}\n")
    f.write(f"Total columns: {df.shape[1]}\n\n")
    
    f.write("Missing Values:\n")
    f.write(str(missing_values[missing_values > 0]) + "\n\n")
    
    f.write(f"Numerical columns: {numerical_cols}\n")
    f.write("Numerical Data Summary:\n")
    f.write(str(df[numerical_cols].describe()) + "\n\n")
    
    f.write(f"Categorical columns: {categorical_cols}\n\n")
    
    f.write("Unique values in categorical columns:\n")
    for col in categorical_cols:
        unique_count = df[col].nunique()
        f.write(f"{col}: {unique_count} unique values\n")
    
    f.write("\nCorrelation between numerical variables:\n")
    f.write(str(correlation))

print(f"\nAnalysis results saved to {output_dir}/data_analysis.txt")
