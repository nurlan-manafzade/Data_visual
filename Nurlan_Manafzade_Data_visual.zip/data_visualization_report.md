# Data Visualization Report

## Overview
This report presents a comprehensive analysis and visualization of the data contained in the "Data_visual.xlsx" file. The dataset contains 51,290 rows and 22 columns of sales data across different regions, categories, and time periods.

## Data Structure
- **Total rows**: 51,290
- **Total columns**: 22
- **No missing values** were found in the dataset

### Key Numerical Variables
- Sales
- Shipping Cost
- Profit
- Quantity
- Discount

### Key Categorical Variables
- Region (13 unique values)
- Country (147 unique values)
- Category (3 unique values)
- Sub-Category (17 unique values)
- Segment (3 unique values)
- Market (4 unique values)

## Key Insights

### Regional Performance
The "Central" region has the highest total sales, followed by "South" and "North" regions. This indicates a strong market presence in these areas.

### Product Categories
Technology products generate the highest profit, followed by Office Supplies and Furniture. This suggests that the technology category should be a focus area for business growth.

### Discount Impact
There is a negative correlation (-0.32) between discount and profit, as visualized in the scatter plot. Higher discounts tend to result in lower profits, suggesting that discount strategies should be carefully managed.

### Sales Distribution
The sales are distributed across different segments, with the highest proportion coming from the Consumer segment, followed by Corporate and Home Office.

### Time Trends
The sales data shows fluctuations over time, with certain periods showing higher sales. This information can be used for inventory planning and marketing campaigns.

### Market Analysis
The dataset covers 4 different markets, with varying sales performance. Understanding these differences can help in tailoring market-specific strategies.

## Visualization Summary
Fifteen different visualizations were created to provide insights into various aspects of the data:

1. **Sales by Region** - Shows total sales across different regions
2. **Profit by Category** - Displays profitability across product categories
3. **Sales Trend Over Time** - Visualizes sales patterns over time
4. **Sales vs. Profit by Category** - Shows relationship between sales and profit
5. **Discount vs. Profit** - Examines the impact of discounts on profitability
6. **Sales Distribution by Segment** - Shows the proportion of sales across segments
7. **Top 10 Countries by Sales** - Focuses on the highest-performing countries
8. **Correlation Heatmap** - Visualizes relationships between numerical variables
9. **Sales by Ship Mode** - Compares sales across shipping methods
10. **Profit Margin by Category** - Shows profit as a percentage of sales
11. **Quantity Distribution** - Shows the distribution of order quantities
12. **Sales by Market** - Compares sales across markets
13. **Monthly Sales Trend** - Shows monthly sales patterns
14. **Quarterly Profit Trend** - Visualizes quarterly profit patterns
15. **Sub-Category Performance** - Compares performance across sub-categories

## Recommendations
Based on the visualizations and analysis:

1. **Focus on Technology**: This category shows the highest profit and should be prioritized.
2. **Review Discount Strategy**: Consider adjusting discount policies given the negative correlation with profit.
3. **Regional Expansion**: The "Central" region performs well; similar strategies could be applied to other regions.
4. **Seasonal Planning**: Use the time trend data to prepare for peak sales periods.
5. **Sub-Category Optimization**: Some sub-categories perform significantly better than others; consider reallocating resources accordingly.

## Conclusion
The data visualizations provide valuable insights into sales performance across various dimensions. These insights can guide strategic decision-making to improve profitability and market presence.
